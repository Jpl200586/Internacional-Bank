Fixed your links!

Url fix.

test code!!

Hey from Vinitha


# Bank Cube:

O Banco Cube esta sendo desenvolvido para estudos de JavaScript com foco em criação de formularios, validação de CPF entre outros metodos utilizados.
Com o tempo teremos aprimorações

## Tech utilizadas

- HTML5
- JS
- CSS
- Git

### JavaScript Validação de formulario;

- Required
- Type
- Min e Max length
- Patter e Regex

# JavaScript:

- addEventListener
- Validação de CPF
- Validação maior idade
- Validity State
- Manipulando o DOM
- Local Storage

## Como rodar este projeto

- Git clone
- Go Live
